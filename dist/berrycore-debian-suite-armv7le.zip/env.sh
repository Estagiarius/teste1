# BerryCore Debian-to-BerryCore Runtime Environment (BlackBerry Q5 / QNX Neutrino)
# Uso no Term49: source /accounts/1000/shared/misc/berrycore/env.sh

export PREFIX="/accounts/1000/shared/misc/berrycore"
export PATH="$PREFIX/bin:$PREFIX/sbin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/lib:$LD_LIBRARY_PATH"
export TERMINFO="$PREFIX/share/terminfo"
export SSL_CERT_FILE="$PREFIX/etc/ssl/certs/ca-certificates.crt"
export CURL_CA_BUNDLE="$PREFIX/etc/ssl/certs/ca-certificates.crt"
export MANPATH="$PREFIX/share/man:$MANPATH"
