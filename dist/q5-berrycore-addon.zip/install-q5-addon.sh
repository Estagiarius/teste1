#!/bin/sh
# Instalador seguro do Q5 Addon Pack sobre o BerryCore oficial (v0.90.x)
set -e

BC="${NATIVE_TOOLS:-/accounts/1000/shared/misc/berrycore}"
SRC_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

echo "=== Instalando Q5 Addon Pack em $BC ==="
mkdir -p "$BC/bin" "$BC/lib" "$BC/etc/skel" "$BC/share/q5-sheet" "$BC/share/q5-addon"

# 1. Binarios exclusivos Q5 (nao sobrescreve env.sh, qpkg, vim, git, curl, openssl, python)
for b in q5-sheet fzy ncdu jq tree q5-setup bc-menu q5-files note q5-ai; do
    if [ -f "$SRC_DIR/bin/$b" ]; then
        cp -f "$SRC_DIR/bin/$b" "$BC/bin/$b"
        chmod 755 "$BC/bin/$b"
        echo "  [+] bin/$b"
    fi
done

# 2. Bibliotecas compartilhadas: instala APENAS se ainda nao existirem no BerryCore oficial
if [ ! -e "$BC/lib/libncursesw.so.6" ]; then
    cp -f "$SRC_DIR/lib/libncursesw.so.6.5" "$BC/lib/libncursesw.so.6.5"
    ln -sf libncursesw.so.6.5 "$BC/lib/libncursesw.so.6"
    echo "  [+] lib/libncursesw.so.6 (adicionada)"
else
    echo "  [=] lib/libncursesw.so.6 ja existe no BerryCore (preservada)"
fi

for lib in libjq.so.1 libonig.so.10; do
    if [ ! -e "$BC/lib/$lib" ]; then
        cp -f "$SRC_DIR/lib/$lib" "$BC/lib/$lib"
        echo "  [+] lib/$lib"
    else
        echo "  [=] lib/$lib ja existe (preservada)"
    fi
done

# 3. Dotfiles e arquivos de exemplo/manual
cp -f "$SRC_DIR/etc/skel/"* "$BC/etc/skel/" 2>/dev/null || true
cp -f "$SRC_DIR/etc/skel/".* "$BC/etc/skel/" 2>/dev/null || true
cp -f "$SRC_DIR/share/q5-sheet/exemplo.csv" "$BC/share/q5-sheet/"
if [ -f "$SRC_DIR/share/q5-addon/MANUAL_INICIANTE_BERRYCORE.md" ]; then
    cp -f "$SRC_DIR/share/q5-addon/MANUAL_INICIANTE_BERRYCORE.md" "$BC/share/q5-addon/"
fi

echo ""
echo "=== Instalacao concluida sem conflitos! ==="
echo "Proximos passos:"
echo "  1. q5-setup        (instala atalhos Q5 preservando seu BerryCore)"
echo "  2. q5-sheet $BC/share/q5-sheet/exemplo.csv"
