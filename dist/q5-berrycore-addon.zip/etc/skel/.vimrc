set nocompatible
syntax on
set number
set wrap
set linebreak
set autoindent
set expandtab
set tabstop=4
set shiftwidth=4
set ignorecase
set smartcase
set incsearch
set hlsearch
set hidden
set laststatus=2
set statusline=%f%m\ [%l/%L]

" Essencial no BlackBerry Q5 (sem tecla Esc física)
inoremap jk <Esc>
inoremap jj <Esc>
