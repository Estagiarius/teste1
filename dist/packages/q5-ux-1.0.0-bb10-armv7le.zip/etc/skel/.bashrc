# BerryCore Q5 Pocket Laptop .bashrc (otimizado para tela 720x720 / ~55 colunas)
export PREFIX="/accounts/1000/shared/misc/berrycore"
[ -f "$PREFIX/env.sh" ] && source "$PREFIX/env.sh"

# Pastas rápidas do BlackBerry 10 (evita digitar caminhos longos no polegar)
export BC="$PREFIX"
export DL="/accounts/1000/shared/downloads"
export DOCS="/accounts/1000/shared/documents"
export NOTES_DIR="${NOTES_DIR:-$DOCS/notes}"
export EDITOR="vim"
export VISUAL="vim"
export PAGER="less -R"
export TERM="${TERM:-xterm-256color}"

# Histórico amplo e sem duplicatas
export HISTCONTROL=ignoreboth:erasedups
export HISTSIZE=5000
export HISTFILESIZE=10000
shopt -s histappend checkwinsize cdspell 2>/dev/null

# Prompt compacto de 1 linha para tela 720x720
PROMPT_DIRTRIM=2
__q5_ps1() {
    local rc=$?
    local c_rc="\[\e[32m\]"
    [ "$rc" -ne 0 ] && c_rc="\[\e[31m\]"
    local br=""
    if command -v git >/dev/null 2>&1; then
        br="$(git rev-parse --abbrev-ref HEAD 2>/dev/null)"
        [ -n "$br" ] && br=" \[\e[33m\]($br)\[\e[0m\]"
    fi
    PS1="\[\e[36m\]\W\[\e[0m\]${br} ${c_rc}>\[\e[0m\] "
}
PROMPT_COMMAND=__q5_ps1

# Aliases de produtividade para 1 polegar
alias ..='cd ..'
alias ...='cd ../..'
alias ll='ls -lh --color=auto'
alias la='ls -lAh --color=auto'
alias l='ls -CF --color=auto'
alias grep='grep --color=auto'
alias g='git'
alias gs='git status -sb'
alias gd='git diff'
alias v='vim'
alias n='nano'
alias f='q5-files'
alias m='bc-menu'
alias clima='curl -s "https://wttr.in/?0&T&lang=pt"'

# Atalhos fuzzy com fzy (histórico, arquivos e diretórios)
fh() {
    local cmd
    cmd="$(history | awk '{$1=""; sub(/^ /, ""); print}' | awk '!seen[$0]++' | fzy -l 12)" || return
    [ -n "$cmd" ] && eval "$cmd"
}
ff() {
    local file
    file="$(find . -maxdepth 4 -type f 2>/dev/null | sed 's|^\./||' | fzy -l 12)" || return
    [ -n "$file" ] && "${EDITOR:-vim}" "$file"
}
fcd() {
    local dir
    dir="$(find . -maxdepth 4 -type d 2>/dev/null | sed 's|^\./||' | fzy -l 12)" || return
    [ -n "$dir" ] && cd "$dir"
}

# Sessão tmux pré-montada de "laptop de bolso"
work() {
    if tmux has-session -t q5 2>/dev/null; then
        tmux attach -t q5
    else
        tmux new-session -d -s q5 -n sh
        tmux new-window -t q5:2 -n files 'q5-files || bash'
        tmux new-window -t q5:3 -n notes 'note || bash'
        tmux select-window -t q5:1
        tmux attach -t q5
    fi
}
